const express = require('express');
const router = express.Router();
const passport = require('passport');
const isAuth = require('./authMiddleware').isAuth;

const {
    homeView,
    getLogin,
    getLogout,
    getRegister,
    postRegister,
    postLogin
} = require('../controllers/user.controller');

// Home/Index - a protected route that requires authentication
router.get('/', isAuth, homeView);

// Login routes
router.get('/login', getLogin);
router.post('/login', passport.authenticate('local', { 
    successRedirect: '/', 
    failureRedirect: '/login',
    failureFlash: true 
}));

// Logout route
router.get('/logout', getLogout);

// Register routes
router.get('/register', getRegister);
router.post('/register', postRegister);

// Catch-all for unhandled routes to maintain a good user experience
router.all('*', (req, res) => {
    res.status(404).send('Page not found');
});

module.exports = router;
