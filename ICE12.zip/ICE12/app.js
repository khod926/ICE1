const express = require('express');
const pug = require('pug');
const userRoutes = require('./routes/user.route'); // Ensure this path is correct based on your project structure
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse request bodies
app.use(express.urlencoded({ extended: false }));

// Serve static files (e.g., CSS, JavaScript, images) from the 'public' directory
app.use(express.static('public'));

// Configure routes
app.use('/', userRoutes);

// Setup Pug as the template engine
app.set("views", `${__dirname}/views`);
app.set("view engine", "pug");

// Basic error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong!');
});

// Listen on the specified port
app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
});
