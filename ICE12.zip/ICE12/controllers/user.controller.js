const bcrypt = require("bcrypt");
const saltRounds = 12;
const MIN_PASSWORD_LENGTH = 8;
const MIN_USERNAME_LENGTH = 5;
const MAX_USERNAME_LENGTH = 25;

const { User } = require("../config/database");

// Function to check if a username already exists in the database
async function userExists(usernameToFind) {
  try {
    return await User.findOne({ username: usernameToFind });
  } catch (err) {
    console.error("Database error while checking username:", err);
    throw err; // Proper error handling in calling function
  }
}

// Function to render the login view with potential messages
function renderLogin(req, res, returnObj = {}) {
  res.render("login", {
    pageTitle: "Login",
    errorMessage: returnObj.errorMessage || "",
    successMessage: returnObj.successMessage || ""
  });
}

// Function to render the registration view with potential error messages
function renderRegister(req, res, errorMessage = "") {
  res.render("register", {
    pageTitle: "Register a New Account",
    errorMessage: errorMessage,
  });
}

// Handling home view rendering
exports.homeView = (req, res) => {
  res.render("home", {
    pageTitle: "INFT 2202 - Home Page",
  });
};

// Login page handler
exports.getLogin = (req, res) => {
  renderLogin(req, res);
};

// Login failure handling
const getLoginFailure = (req, res) => {
  renderLogin(req, res, { errorMessage: "Username/password combination does not exist. Please try again."});
};

// Successful login handling
const getLoginSuccess = (req, res) => {
  res.render("login-success", {
    pageTitle: "Login Successful",
    user: req.user // Assuming user object is attached to request
  });
};

// Processing login form submissions
exports.postLogin = async (req, res) => {
  let { username, password } = req.body;
  try {
    const user = await userExists(username);
    if (user && await bcrypt.compare(password, user.hashPassword)) {
      getLoginSuccess(req, res);
    } else {
      getLoginFailure(req, res);
    }
  } catch (err) {
    console.error("Login error:", err);
    getLoginFailure(req, res);
  }
};

// Logout handling
exports.getLogout = (req, res) => {
  req.logout(); // Assuming Passport.js middleware is used to handle session
  renderLogin(req, res, { successMessage: "Successfully logged out."});
};

// Register page handler
exports.getRegister = (req, res) => {
  renderRegister(req, res);
};

// Processing registration form submissions
exports.postRegister = async (req, res) => {
  const { username, password } = req.body;
  if (!username || username.length < MIN_USERNAME_LENGTH || username.length > MAX_USERNAME_LENGTH ||
      !password || password.length < MIN_PASSWORD_LENGTH) {
    renderRegister(req, res, "Validation error: Check username or password criteria.");
    return;
  }
  try {
    if (await userExists(username)) {
      renderRegister(req, res, "Username already in use, please try another.");
    } else {
      const hashedPassword = await bcrypt.hash(password, saltRounds);
      const newUser = new User({ username, hashPassword: hashedPassword });
      await newUser.save();
      renderLogin(req, res, { successMessage: "Registration successful. Please log in." });
    }
  } catch (err) {
    console.error("Registration error:", err);
    renderRegister(req, res, "Unable to register. Database error.");
  }
};

module.exports = exports;
