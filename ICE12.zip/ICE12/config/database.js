const mongoose = require('mongoose');

// Set up default mongoose connection
const mongoDB = process.env.MONGO_URI || 'mongodb://localhost/my_database';
mongoose.connect(mongoDB, { useNewUrlParser: true, useUnifiedTopology: true });

// Get the default connection
const db = mongoose.connection;

// Bind connection to error event (to get notification of connection errors)
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// Define a schema
const Schema = mongoose.Schema;

const UserSchema = new Schema({
    username: { type: String, required: true, unique: true, maxlength: 100 },
    hashPassword: { type: String, required: true },
    created_at: { type: Date, default: Date.now }
});

// Compile model from schema
const User = mongoose.model('User', UserSchema);

module.exports = {
    User // Exporting the User model for use in other files
};

