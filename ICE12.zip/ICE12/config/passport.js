const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const connection = require('./database');
const { validPassword } = require('../lib/passwordUtils');
const User = connection.models.User;

// Passport Local Strategy for authentication
passport.use(new LocalStrategy(
    function(username, password, done) {
        User.findOne({ username: username }, function (err, user) {
            if (err) {
                return done(err);
            }
            if (!user) {
                return done(null, false, { message: 'Incorrect username.' });
            }
            if (!validPassword(password, user.hashPassword)) {
                return done(null, false, { message: 'Incorrect password.' });
            }
            return done(null, user);
        });
    }
));

// SerializeUser determines what data from the user object should be stored in the session
passport.serializeUser((user, done) => {
    done(null, user.id); // Storing user id in the session
});

// DeserializeUser is used to retrieve the whole object from the session based on the user id
passport.deserializeUser((id, done) => {
    User.findById(id, function (err, user) {
        if (err) { 
            done(err);
            return;
        }
        done(null, user); // The user object is attached to the request as req.user
    });
});
