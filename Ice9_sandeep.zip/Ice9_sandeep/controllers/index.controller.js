// index.controller.js
exports.homeView = (req, res) => {
    res.render('index', { pageTitle: 'Home' });
  };
  
  exports.aboutView = (req, res) => {
    res.render('index', { pageTitle: 'About' });
  };
  