const express = require('express');
const router = express.Router();
const indexController = require('../controllers/index.controller');

router.get('/', indexController.homeView);
router.get('/about', indexController.aboutView);

module.exports = router;