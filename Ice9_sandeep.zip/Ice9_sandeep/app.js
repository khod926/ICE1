// app.js

const express = require('express');
const path = require('path');
const indexRouter = require('./routes/index.router');

const app = express();

// Set up view engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// Use routes
app.use('/', indexRouter);

// Define port
const PORT = process.env.PORT || 3000;

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
